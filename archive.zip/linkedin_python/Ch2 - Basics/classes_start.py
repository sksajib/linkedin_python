#
# Example file for working with classes
# LinkedIn Learning Python course by Joe Marini
#

