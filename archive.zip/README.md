# linkedin_python
Learn python
